
export function Footer() {
    return (
      <>
      <div id="footer">
        <p id="created">Created by: Grant Rulon, Colby Schneider and Heather White</p>
        <p id="copywrite">&copy; 2022</p>
      </div>
      </>
    );
    }
  
  export default Footer;