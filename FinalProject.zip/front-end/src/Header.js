
  export function Header() {
  return (
    <>
    <div>
      <h1>The Todo App</h1>
    </div>
    </>
  );
  }

export default Header;